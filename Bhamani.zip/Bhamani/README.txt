Shakeel Bhamani
shakeel.bhamani@gatech.edu

In Eclipse, I said to use Java 1.7.x for this project, while my computer is running Java 1.8.x. So this should work on Java 1.7,
but I don't understand how to check the java version for my actual Courier.java file.

I also added one more tab "Clock" for Extra Credit!